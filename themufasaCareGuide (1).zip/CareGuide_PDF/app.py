"""CareGuide AI (PDF Edition) — Advanced GUI"""
import os, sys, threading, datetime
from pathlib import Path
from tkinter import messagebox, filedialog

sys.path.insert(0, str(Path(__file__).parent))

try:
    import customtkinter as ctk
except ImportError:
    print("Run: pip install customtkinter"); sys.exit(1)

from dotenv import load_dotenv
load_dotenv()

# ── Colours ──────────────────────────────────────────────────────────────────
JADE      = "#4ADE80"; JADE_DIM = "#22C55E"; JADE_DARK = "#16A34A"
AMBER     = "#FCD34D"; ROSE     = "#FB7185"; CYAN      = "#67E8F9"
VIOLET    = "#A78BFA"; BG       = "#0B0F0C"; BG2       = "#111612"
SURFACE   = "#1A201B"; SURFACE2 = "#202820"; BORDER    = "#2A342B"
TEXT      = "#E8EDE9"; TEXT2    = "#9BA89D"; TEXT3     = "#5C6B5E"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("green")

# ── Knowledge base PDF list ───────────────────────────────────────────────────
KB_PDFS = [
    ("📄", "01_types_of_home_care",          "What types of in-home care services are available?"),
    ("💰", "02_costs_and_pricing",            "How much does in-home care cost per hour?"),
    ("🏥", "03_medicare_medicaid_coverage",   "What does Medicare cover for home care?"),
    ("🧠", "04_dementia_alzheimers_care",     "What specialized care is available for dementia?"),
    ("👤", "05_hiring_a_caregiver",           "What should I look for when hiring a caregiver?"),
    ("📋", "06_caregiver_qualifications",     "What qualifications should a good caregiver have?"),
    ("🩺", "07_post_surgery_discharge_care",  "What home care is needed after hospital discharge?"),
    ("🛡", "08_safety_aging_in_place",        "How do I make my parent's home safer?"),
    ("❤",  "09_chronic_conditions_care",      "How do I manage chronic conditions at home?"),
    ("🌿", "10_respite_care_burnout",         "What respite care options exist to prevent burnout?"),
    ("❓", "11_questions_to_ask_agencies",    "What questions should I ask home care agencies?"),
    ("🏠", "12_caregivers_com_service_guide", "What services does caregivers.com provide?"),
]

QUICK_TOPICS = [
    ("1",  "Types of Home Care",   "What types of in-home care services are available?"),
    ("2",  "Costs & Pricing",      "How much does in-home care cost per hour in 2024?"),
    ("3",  "Medicare Coverage",    "Does Medicare cover home care for seniors?"),
    ("4",  "Dementia Care",        "What specialized care is available for dementia?"),
    ("5",  "Post-Surgery",         "What home care is needed after hospital discharge?"),
    ("6",  "Hiring a Caregiver",   "What should I look for when hiring a caregiver?"),
    ("7",  "Qualifications",       "What qualifications should a good caregiver have?"),
    ("8",  "Home Safety",          "How do I make my parent's home safer for aging in place?"),
    ("9",  "Chronic Conditions",   "How do I manage chronic conditions like diabetes at home?"),
    ("10", "Respite & Burnout",    "What respite care options exist to prevent burnout?"),
    ("11", "Agency Questions",     "What questions should I ask home care agencies?"),
    ("12", "caregivers.com",       "What services does caregivers.com provide?"),
]


class CareGuideApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("CareGuide AI (PDF Edition)  —  RAG Interface")
        self.geometry("1300x820"); self.minsize(1050, 680)
        self.configure(fg_color=BG)

        self.rag             = None
        self.is_ready        = False
        self.is_processing   = False
        self.is_initializing = False
        self.conversation    = []
        self.total_cost      = 0.0
        self.total_tokens    = 0
        self.query_count     = 0

        self._build_header()
        self._build_workspace()
        self._build_statusbar()
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.after(800, self._auto_init)

    # ══ HEADER ════════════════════════════════════════════════════════════════
    def _build_header(self):
        hdr = ctk.CTkFrame(self, fg_color=BG2, height=52, corner_radius=0)
        hdr.pack(fill="x"); hdr.pack_propagate(False)

        lf = ctk.CTkFrame(hdr, fg_color="transparent")
        lf.pack(side="left", padx=16, pady=8)
        ctk.CTkLabel(lf, text="🏠", font=("Segoe UI Emoji", 20)).pack(side="left", padx=(0, 6))
        ctk.CTkLabel(lf, text="CareGuide", font=("Helvetica", 16, "bold"), text_color=TEXT).pack(side="left")
        ctk.CTkLabel(lf, text=" AI", font=("Helvetica", 16, "bold"), text_color=JADE).pack(side="left")
        ctk.CTkLabel(lf, text=" PDF Edition · RAG", font=("Courier", 10), text_color=TEXT3).pack(side="left", padx=(8, 0))

        rf = ctk.CTkFrame(hdr, fg_color="transparent")
        rf.pack(side="right", padx=12, pady=8)
        self.status_label = ctk.CTkLabel(rf, text="⬤  Not initialized",
                                          font=("Courier", 11), text_color=TEXT3)
        self.status_label.pack(side="left", padx=(0, 12))
        for txt, cmd in [("🗑 Clear", self._clear_chat), ("↗ Export", self._export_chat)]:
            ctk.CTkButton(rf, text=txt, width=80, height=30, fg_color=SURFACE2,
                          hover_color=SURFACE, text_color=TEXT2, corner_radius=8,
                          command=cmd).pack(side="left", padx=3)

    # ══ WORKSPACE ═════════════════════════════════════════════════════════════
    def _build_workspace(self):
        ws = ctk.CTkFrame(self, fg_color="transparent")
        ws.pack(fill="both", expand=True)
        self._build_left(ws)
        self._build_center(ws)
        self._build_right(ws)

    # ── Left sidebar ──────────────────────────────────────────────────────────
    def _build_left(self, parent):
        left = ctk.CTkFrame(parent, fg_color=BG2, width=240, corner_radius=0)
        left.pack(side="left", fill="y"); left.pack_propagate(False)
        scroll = ctk.CTkScrollableFrame(left, fg_color="transparent",
                                         scrollbar_button_color=BORDER)
        scroll.pack(fill="both", expand=True)

        self._slabel(scroll, "API CONFIGURATION")
        ctk.CTkLabel(scroll, text="OpenAI API Key", font=("Courier", 10),
                     text_color=TEXT2, anchor="w").pack(fill="x", padx=14, pady=(0, 3))
        self.api_key_entry = ctk.CTkEntry(scroll, show="•", height=32,
                                           placeholder_text="sk-...",
                                           fg_color=SURFACE, border_color=BORDER,
                                           text_color=TEXT, font=("Courier", 11))
        self.api_key_entry.pack(fill="x", padx=12, pady=(0, 8))
        if os.getenv("OPENAI_API_KEY"):
            self.api_key_entry.insert(0, os.getenv("OPENAI_API_KEY"))

        ctk.CTkLabel(scroll, text="Model", font=("Courier", 10),
                     text_color=TEXT2, anchor="w").pack(fill="x", padx=14, pady=(0, 3))
        self.model_var = ctk.StringVar(value=os.getenv("OPENAI_MODEL", "gpt-3.5-turbo"))
        ctk.CTkOptionMenu(scroll, variable=self.model_var, height=32,
                          fg_color=SURFACE, button_color=SURFACE2,
                          button_hover_color=BORDER, text_color=TEXT,
                          values=["gpt-3.5-turbo", "gpt-4o-mini", "gpt-4o",
                                  "gpt-4-turbo", "gpt-4"]
                          ).pack(fill="x", padx=12, pady=(0, 8))

        ctk.CTkLabel(scroll, text="Temperature", font=("Courier", 10),
                     text_color=TEXT2, anchor="w").pack(fill="x", padx=14, pady=(0, 3))
        tr = ctk.CTkFrame(scroll, fg_color="transparent"); tr.pack(fill="x", padx=12, pady=(0, 8))
        self.temp_var   = ctk.DoubleVar(value=0.3)
        self.temp_label = ctk.CTkLabel(tr, text="0.3", font=("Courier", 11),
                                        text_color=JADE, width=30)
        self.temp_label.pack(side="right")
        ctk.CTkSlider(tr, from_=0, to=2, number_of_steps=20, variable=self.temp_var,
                      progress_color=JADE, button_color=JADE_DIM,
                      command=lambda v: self.temp_label.configure(text=f"{float(v):.1f}")
                      ).pack(side="left", fill="x", expand=True, padx=(0, 6))

        ctk.CTkButton(scroll, text="🚀  Initialize", height=36,
                      fg_color=JADE_DARK, hover_color=JADE_DIM,
                      text_color="#0B1A0E", font=("Helvetica", 12, "bold"),
                      corner_radius=8, command=self._init_rag
                      ).pack(fill="x", padx=12, pady=(4, 4))

        ctk.CTkButton(scroll, text="🔄  Rebuild Index", height=30,
                      fg_color=SURFACE2, hover_color=SURFACE,
                      text_color=TEXT2, font=("Helvetica", 11), corner_radius=8,
                      command=lambda: self._run_cmd("rebuild")
                      ).pack(fill="x", padx=12, pady=(0, 12))

        self._div(scroll)
        self._slabel(scroll, "QUICK TOPICS")
        for num, label, q in QUICK_TOPICS:
            ctk.CTkButton(scroll, text=f"  {num}  {label}", height=28, anchor="w",
                          fg_color="transparent", hover_color=SURFACE,
                          text_color=TEXT2, font=("Helvetica", 11), corner_radius=6,
                          command=lambda qq=q: self._send_query(qq)
                          ).pack(fill="x", padx=10, pady=1)

        self._div(scroll)
        self._slabel(scroll, "COMMANDS")
        cf = ctk.CTkFrame(scroll, fg_color="transparent"); cf.pack(fill="x", padx=12, pady=(0, 8))
        for txt, cmd in [("📊 Metrics", "metrics"), ("📋 Topics", "topics"), ("🗑 Clear", "clear")]:
            ctk.CTkButton(cf, text=txt, height=26, fg_color=SURFACE2,
                          hover_color=SURFACE, text_color=TEXT2,
                          font=("Helvetica", 10), corner_radius=6,
                          command=lambda c=cmd: self._run_cmd(c)
                          ).pack(side="left", padx=2, pady=2)

    # ── Center chat area ──────────────────────────────────────────────────────
    def _build_center(self, parent):
        center = ctk.CTkFrame(parent, fg_color=BG, corner_radius=0)
        center.pack(side="left", fill="both", expand=True)

        # Pipeline bar
        pb = ctk.CTkFrame(center, fg_color=BG2, height=32, corner_radius=0)
        pb.pack(fill="x"); pb.pack_propagate(False)
        self.pipe_labels = {}
        inner = ctk.CTkFrame(pb, fg_color="transparent"); inner.pack(side="left", padx=12, pady=4)
        steps = ["PDF Load", "Embed", "BM25", "Semantic", "MMR", "Confidence", "Generate", "Stream"]
        for i, s in enumerate(steps):
            lbl = ctk.CTkLabel(inner, text=s, font=("Courier", 9), text_color=TEXT3)
            lbl.pack(side="left", padx=2); self.pipe_labels[s] = lbl
            if i < len(steps) - 1:
                ctk.CTkLabel(inner, text="›", font=("Courier", 10), text_color=TEXT3).pack(side="left")

        # Header bar
        ch = ctk.CTkFrame(center, fg_color=BG2, height=40, corner_radius=0)
        ch.pack(fill="x"); ch.pack_propagate(False)
        ctk.CTkLabel(ch, text="CareGuide AI — PDF Knowledge Base",
                     font=("Helvetica", 14, "bold"), text_color=TEXT
                     ).pack(side="left", padx=16)
        self.stats_label = ctk.CTkLabel(ch, text="Queries: 0  |  Vectors: —  |  PDFs: 12",
                                         font=("Courier", 10), text_color=TEXT3)
        self.stats_label.pack(side="right", padx=16)

        # Chat messages
        self.chat_frame = ctk.CTkScrollableFrame(center, fg_color=BG,
                                                   scrollbar_button_color=BORDER)
        self.chat_frame.pack(fill="both", expand=True)
        self._add_welcome()

        # Input area
        ia = ctk.CTkFrame(center, fg_color=BG2, corner_radius=0)
        ia.pack(fill="x", side="bottom")
        shell = ctk.CTkFrame(ia, fg_color=SURFACE, border_color=BORDER,
                              border_width=1, corner_radius=12)
        shell.pack(fill="x", padx=16, pady=12)
        self.chat_input = ctk.CTkTextbox(shell, height=52, fg_color=SURFACE,
                                          text_color=TEXT, font=("Helvetica", 13),
                                          border_width=0, wrap="word",
                                          scrollbar_button_color=SURFACE)
        self.chat_input.pack(side="left", fill="both", expand=True, padx=12, pady=8)
        self.chat_input.bind("<Return>", self._on_enter)
        bf = ctk.CTkFrame(shell, fg_color="transparent"); bf.pack(side="right", padx=8, pady=8)
        self.send_btn = ctk.CTkButton(bf, text="Send →", width=80, height=36,
                                       fg_color=JADE_DARK, hover_color=JADE_DIM,
                                       text_color="#0B1A0E", font=("Helvetica", 12, "bold"),
                                       corner_radius=9, command=self._send_from_input)
        self.send_btn.pack()
        ctk.CTkLabel(ia, text="Enter to send  ·  Shift+Enter for newline",
                     font=("Courier", 9), text_color=TEXT3).pack(pady=(0, 6))

    # ── Right panel ───────────────────────────────────────────────────────────
    def _build_right(self, parent):
        right = ctk.CTkFrame(parent, fg_color=BG2, width=260, corner_radius=0)
        right.pack(side="right", fill="y"); right.pack_propagate(False)

        tv = ctk.CTkTabview(right, fg_color=BG2)
        tv.pack(fill="both", expand=True)
        self._build_metrics_tab(tv.add("Metrics"))
        self._build_log_tab(tv.add("API Log"))
        self._build_kb_tab(tv.add("PDFs"))
        self._build_rag_tab(tv.add("RAG"))

    def _build_metrics_tab(self, parent):
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent",
                                         scrollbar_button_color=BORDER)
        scroll.pack(fill="both", expand=True)
        grid = ctk.CTkFrame(scroll, fg_color="transparent"); grid.pack(fill="x", padx=10, pady=10)
        grid.columnconfigure((0, 1), weight=1)
        self._ml = {}
        for i, (label, val, color, key) in enumerate([
            ("Queries", "0", JADE, "q"),   ("Vectors", "—", CYAN, "v"),
            ("Tokens",  "0", AMBER, "t"),  ("PDFs",    "12", JADE, "d"),
            ("Cost",    "$0", VIOLET, "c"),("Memory",  "0/8", TEXT2, "m")]):
            card = ctk.CTkFrame(grid, fg_color=SURFACE, corner_radius=8)
            card.grid(row=i // 2, column=i % 2, padx=3, pady=3, sticky="ew")
            lv = ctk.CTkLabel(card, text=val, font=("Helvetica", 22, "bold"), text_color=color)
            lv.pack(pady=(8, 2))
            ctk.CTkLabel(card, text=label, font=("Courier", 9), text_color=TEXT3).pack(pady=(0, 8))
            self._ml[key] = lv

        pf = ctk.CTkFrame(scroll, fg_color="transparent"); pf.pack(fill="x", padx=10, pady=(4, 10))
        self._pb = {}; self._pl = {}
        for label, color, key in [
            ("Confidence Avg", AMBER, "conf"),
            ("Memory k=8",     VIOLET, "mem"),
            ("Token Budget",   CYAN, "tok")]:
            ctk.CTkLabel(pf, text=label, font=("Courier", 9), text_color=TEXT2, anchor="w").pack(fill="x", pady=(6, 1))
            pb = ctk.CTkProgressBar(pf, progress_color=color, fg_color=SURFACE, height=4)
            pb.pack(fill="x", pady=(0, 2)); pb.set(0); self._pb[key] = pb
            pl = ctk.CTkLabel(pf, text="0%", font=("Courier", 9), text_color=TEXT3)
            pl.pack(anchor="e"); self._pl[key] = pl

        cc = ctk.CTkFrame(scroll, fg_color=SURFACE, corner_radius=10)
        cc.pack(fill="x", padx=10, pady=(4, 10))
        ctk.CTkLabel(cc, text="Session Cost", font=("Courier", 9), text_color=TEXT3).pack(pady=(10, 0))
        self.cost_lbl = ctk.CTkLabel(cc, text="$0.00000",
                                      font=("Helvetica", 20, "bold"), text_color=VIOLET)
        self.cost_lbl.pack(pady=(2, 10))

    def _build_log_tab(self, parent):
        self.api_log = ctk.CTkTextbox(parent, fg_color="#080C09", text_color="#7FD99A",
                                       font=("Courier", 10), wrap="word", border_width=0)
        self.api_log.pack(fill="both", expand=True, padx=8, pady=8)
        self.api_log.insert("end", "// API Log ready\n// Send a message to see\n// live request/response data\n")
        self.api_log.configure(state="disabled")

    def _build_kb_tab(self, parent):
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent",
                                         scrollbar_button_color=BORDER)
        scroll.pack(fill="both", expand=True)
        ctk.CTkLabel(scroll, text="PDF KNOWLEDGE BASE", font=("Courier", 9, "bold"),
                     text_color=TEXT3, anchor="w").pack(fill="x", padx=10, pady=(8, 4))
        for icon, name, q in KB_PDFS:
            card = ctk.CTkFrame(scroll, fg_color=SURFACE, corner_radius=7)
            card.pack(fill="x", padx=8, pady=2)
            ctk.CTkButton(card, text=f"{icon}  {name}.pdf", height=30, anchor="w",
                          fg_color="transparent", hover_color=SURFACE2,
                          text_color=TEXT2, font=("Courier", 9), corner_radius=6,
                          command=lambda qq=q: self._send_query(qq)
                          ).pack(side="left", fill="x", expand=True, padx=4)

    def _build_rag_tab(self, parent):
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent",
                                         scrollbar_button_color=BORDER)
        scroll.pack(fill="both", expand=True)
        feats = [
            (JADE,  "PDF Text Extraction",       "pypdf"),
            (JADE,  "Hybrid BM25 + Semantic",    "Direct SDK"),
            (JADE,  "MMR Deduplication",          "Custom"),
            (JADE,  "Confidence Scoring",         "rag_engine.py"),
            (JADE,  "Conversation Memory k=8",    "rag_engine.py"),
            (JADE,  "ChromaDB Persistence",       "chroma_db/"),
            (JADE,  "Source Attribution",         "rag_engine.py"),
            (JADE,  "Graceful Error Handling",    "rag_engine.py"),
            ("#FB7185", "Crisis Detection (911)", "CRISIS_RE regex"),
            (AMBER, "12-PDF Knowledge Base",      "documents/"),
            (CYAN,  "Token & Cost Tracking",      "app.py"),
            (VIOLET,"Pipeline Visualiser",        "app.py"),
        ]
        for color, name, loc in feats:
            card = ctk.CTkFrame(scroll, fg_color=SURFACE, corner_radius=7)
            card.pack(fill="x", padx=8, pady=2)
            ctk.CTkLabel(card, text="●", font=("Courier", 10), text_color=color
                         ).pack(side="left", padx=(10, 6), pady=8)
            ctk.CTkLabel(card, text=name, font=("Courier", 9), text_color=TEXT2,
                         anchor="w").pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(card, text=loc, font=("Courier", 9), text_color=TEXT3
                         ).pack(side="right", padx=10)

    # ══ STATUS BAR ════════════════════════════════════════════════════════════
    def _build_statusbar(self):
        bar = ctk.CTkFrame(self, fg_color=BG2, height=24, corner_radius=0)
        bar.pack(fill="x", side="bottom"); bar.pack_propagate(False)
        self.sb_label = ctk.CTkLabel(bar, text="  Ready. Enter API key and click Initialize.",
                                      font=("Courier", 9), text_color=TEXT3, anchor="w")
        self.sb_label.pack(side="left", padx=8)
        self.clock_lbl = ctk.CTkLabel(bar, text="", font=("Courier", 9), text_color=TEXT3)
        self.clock_lbl.pack(side="right", padx=8)
        self._tick()

    def _tick(self):
        self.clock_lbl.configure(text=datetime.datetime.now().strftime("%H:%M:%S"))
        self.after(1000, self._tick)

    # ══ CHAT BUBBLES ══════════════════════════════════════════════════════════
    def _add_welcome(self):
        f = ctk.CTkFrame(self.chat_frame, fg_color="transparent")
        f.pack(fill="both", expand=True, pady=40)
        ctk.CTkLabel(f, text="🏠", font=("Segoe UI Emoji", 48)).pack()
        ctk.CTkLabel(f, text="CareGuide AI", font=("Helvetica", 24, "bold"), text_color=TEXT).pack(pady=(8, 4))
        ctk.CTkLabel(f, text="PDF Edition  ·  Hybrid BM25 + Semantic Search\n12 expanded PDF documents · Crisis detection active",
                     font=("Helvetica", 12), text_color=TEXT2, justify="center").pack()
        ctk.CTkLabel(f, text="→ Enter your API key on the left and click Initialize, then ask anything.",
                     font=("Courier", 10), text_color=TEXT3).pack(pady=(16, 0))
        self._welcome = f

    def _rm_welcome(self):
        if hasattr(self, "_welcome") and self._welcome.winfo_exists():
            self._welcome.destroy()

    def _add_user_bubble(self, text):
        self._rm_welcome()
        outer = ctk.CTkFrame(self.chat_frame, fg_color="transparent"); outer.pack(fill="x", pady=(4, 0))
        wrap  = ctk.CTkFrame(outer, fg_color="transparent"); wrap.pack(side="right", padx=16)
        bubble = ctk.CTkFrame(wrap, fg_color="#1a1f3a", corner_radius=12,
                               border_width=1, border_color="#2a2f5a")
        bubble.pack()
        ctk.CTkLabel(bubble, text=text, font=("Helvetica", 13), text_color=TEXT,
                     wraplength=480, justify="left", anchor="w").pack(padx=14, pady=10)
        meta = ctk.CTkFrame(wrap, fg_color="transparent"); meta.pack(anchor="e")
        ctk.CTkLabel(meta, text=datetime.datetime.now().strftime("%H:%M"),
                     font=("Courier", 9), text_color=TEXT3).pack(side="right")
        self._scroll_bottom()

    def _add_bot_bubble(self, text, sources, confidence, resp_time, is_crisis=False):
        self._rm_welcome()
        conf_colors = {"high": JADE, "medium": AMBER, "low": ROSE, "crisis": ROSE}
        conf_labels = {"high": "🟢 High", "medium": "🟡 Medium", "low": "🔴 Low", "crisis": "🚨 Emergency"}
        bg = "#1A0B0D" if is_crisis else SURFACE
        bc = "#4A1A1F" if is_crisis else BORDER

        outer   = ctk.CTkFrame(self.chat_frame, fg_color="transparent"); outer.pack(fill="x", pady=(4, 4))
        row     = ctk.CTkFrame(outer, fg_color="transparent"); row.pack(side="left", padx=16, fill="x", expand=True)
        av      = ctk.CTkFrame(row, fg_color="#1A3020", width=30, height=30,
                                corner_radius=9, border_width=1, border_color="#2A5030")
        av.pack(side="left", anchor="n", pady=2); av.pack_propagate(False)
        ctk.CTkLabel(av, text="🏠", font=("Segoe UI Emoji", 14)).pack(expand=True)
        content = ctk.CTkFrame(row, fg_color="transparent"); content.pack(side="left", fill="x", expand=True, padx=(8, 0))
        bubble  = ctk.CTkFrame(content, fg_color=bg, corner_radius=12, border_width=1, border_color=bc)
        bubble.pack(fill="x")
        ctk.CTkLabel(bubble, text=text, font=("Helvetica", 13), text_color=TEXT,
                     wraplength=520, justify="left", anchor="w").pack(padx=14, pady=10)
        if sources:
            sr = ctk.CTkFrame(content, fg_color="transparent"); sr.pack(fill="x", pady=(2, 0))
            for s in sources:
                ctk.CTkLabel(sr, text=f"📄 {s}", font=("Courier", 9), text_color=JADE_DIM,
                             fg_color=SURFACE, corner_radius=4
                             ).pack(side="left", padx=(0, 4), ipadx=4, ipady=2)
        mr = ctk.CTkFrame(content, fg_color="transparent"); mr.pack(fill="x", pady=(3, 0))
        ctk.CTkLabel(mr, text=datetime.datetime.now().strftime("%H:%M"),
                     font=("Courier", 9), text_color=TEXT3).pack(side="left")
        ctk.CTkLabel(mr, text=conf_labels.get(confidence, "🟡 Medium"),
                     font=("Courier", 9), text_color=conf_colors.get(confidence, AMBER),
                     fg_color=SURFACE, corner_radius=4
                     ).pack(side="left", padx=6, ipadx=4, ipady=2)
        if resp_time > 0:
            ctk.CTkLabel(mr, text=f"{resp_time:.1f}s",
                         font=("Courier", 9), text_color=TEXT3).pack(side="left", padx=4)
        self._scroll_bottom()

    def _add_sys_msg(self, text, color=TEXT3):
        f = ctk.CTkFrame(self.chat_frame, fg_color="transparent"); f.pack(fill="x", pady=2)
        ctk.CTkLabel(f, text=text, font=("Courier", 10), text_color=color, anchor="center").pack(fill="x", padx=20)

    def _scroll_bottom(self):
        self.after(50, lambda: self.chat_frame._parent_canvas.yview_moveto(1.0))

    # ══ PIPELINE ANIMATION ════════════════════════════════════════════════════
    def _reset_pipe(self):
        for l in self.pipe_labels.values(): l.configure(text_color=TEXT3)

    def _animate_pipe(self, on_done):
        steps  = ["PDF Load", "Embed", "BM25", "Semantic", "MMR", "Confidence", "Generate", "Stream"]
        delays = [140, 180, 260, 260, 220, 180, 150, 100]
        self._reset_pipe()
        def _next(i):
            if i > 0: self.pipe_labels[steps[i - 1]].configure(text_color=JADE_DIM)
            if i >= len(steps): on_done(); return
            self.pipe_labels[steps[i]].configure(text_color=JADE)
            self.after(delays[i], lambda: _next(i + 1))
        _next(0)

    # ══ QUERY ═════════════════════════════════════════════════════════════════
    def _send_from_input(self):
        text = self.chat_input.get("1.0", "end").strip()
        if text: self.chat_input.delete("1.0", "end"); self._send_query(text)

    def _on_enter(self, event):
        if not (event.state & 0x1): self._send_from_input(); return "break"

    def _send_query(self, text):
        if self.is_processing or not text.strip(): return
        self._add_user_bubble(text)
        self.conversation.append({"role": "user", "content": text})
        if not self.is_ready or not self.rag:
            self._add_bot_bubble(
                "🔑 System not initialized.\n\nPlease enter your OpenAI API key and click Initialize.",
                [], "low", 0)
            return
        self.is_processing = True
        self.send_btn.configure(state="disabled", text="…")
        self._set_status("loading", "Processing…")
        def on_pipe_done():
            threading.Thread(
                target=lambda: self.after(0, lambda: self._handle_result(self.rag.query(text))),
                daemon=True).start()
        self._animate_pipe(on_pipe_done)

    def _handle_result(self, r):
        if r["is_crisis"]: self._show_crisis()
        self._add_bot_bubble(r["answer"], r["sources"], r["confidence"],
                              r["response_time"], r["is_crisis"])
        self.conversation.append({"role": "assistant", "content": r["answer"],
                                   "confidence": r["confidence"]})
        self.query_count  += 1
        self.total_tokens += r.get("usage", {}).get("total_tokens", 0)
        model = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")
        rates = {"gpt-3.5-turbo": [1.5, 2.0], "gpt-4o-mini": [0.15, 0.6],
                 "gpt-4o": [5, 15], "gpt-4-turbo": [10, 30], "gpt-4": [30, 60]}
        rt = rates.get(model, [1.5, 2.0])
        u  = r.get("usage", {})
        self.total_cost += (u.get("prompt_tokens", 0) * rt[0] +
                             u.get("completion_tokens", 0) * rt[1]) / 1_000_000
        self._update_metrics()
        self._update_log(r)
        self.is_processing = False
        self.send_btn.configure(state="normal", text="Send →")
        self._set_status("ready", "✅ Ready")

    # ══ COMMANDS ══════════════════════════════════════════════════════════════
    def _run_cmd(self, cmd):
        if cmd == "clear":
            self._clear_chat(); return
        if cmd == "metrics":
            s = self.rag.get_stats() if self.rag else {}
            self._add_bot_bubble(
                f"System Metrics\n\nQueries: {self.query_count}\n"
                f"Vectors: {s.get('vectors', '—')}\n"
                f"PDF Documents: {s.get('documents', 12)}\n"
                f"Model: {s.get('model', 'gpt-3.5-turbo')}\n"
                f"Search: {s.get('search_mode', 'Hybrid BM25 + Semantic (PDF)')}\n"
                f"Memory turns: {s.get('memory_k', 8)}\n"
                f"Status: {'Ready' if self.is_ready else 'Not initialized'}",
                [], "high", 0)
        elif cmd == "rebuild":
            if not self.rag:
                self._add_bot_bubble("Initialize first.", [], "low", 0); return
            self._add_sys_msg("── Rebuilding PDF index… ──", AMBER)
            threading.Thread(
                target=lambda: self.rag.rebuild_index(
                    lambda m: self.after(0, lambda mm=m: self._add_sys_msg(f"  {mm}", TEXT3))
                ) and self.after(0, lambda: self._on_init_done(True)),
                daemon=True).start()
        elif cmd == "topics":
            self._add_bot_bubble(
                "Available Topics (from PDF Knowledge Base)\n\n"
                "1 — Types of in-home care\n2 — Costs & pricing\n"
                "3 — Medicare & Medicaid\n4 — Dementia & Alzheimer's\n"
                "5 — Post-surgery care\n6 — Hiring a caregiver\n"
                "7 — Caregiver qualifications\n8 — Home safety\n"
                "9 — Chronic conditions\n10 — Respite & burnout\n"
                "11 — Agency questions\n12 — caregivers.com services\n\n"
                "All answers sourced directly from your PDF knowledge base.",
                [], "high", 0)

    # ══ INIT ══════════════════════════════════════════════════════════════════
    def _auto_init(self):
        key = os.getenv("OPENAI_API_KEY", "")
        if key and key != "sk-your-key-here": self._init_rag()

    def _init_rag(self):
        if self.is_initializing: return
        key = self.api_key_entry.get().strip()
        if not key:
            messagebox.showerror("API Key Missing", "Please enter your OpenAI API key."); return
        self.is_initializing = True
        os.environ["OPENAI_API_KEY"] = key
        os.environ["OPENAI_MODEL"]   = self.model_var.get()
        os.environ["TEMPERATURE"]    = str(self.temp_var.get())
        self._set_status("loading", "Initializing…")
        self._add_sys_msg("── Initializing CareGuide AI (PDF Edition)… ──", TEXT3)

        docs_dir = str(Path(__file__).parent / "documents")
        pdf_count = len(list(Path(docs_dir).glob("*.pdf"))) if Path(docs_dir).exists() else 0
        if pdf_count == 0:
            self._add_bot_bubble(
                "⚠️ No PDF files found in the documents/ folder.\n\n"
                "Please copy your 12 PDF knowledge base files into:\n"
                f"{docs_dir}",
                [], "low", 0)
            self.is_initializing = False
            return

        self._add_sys_msg(f"  Found {pdf_count} PDF files. Extracting and embedding…", JADE)

        from src.rag_engine import CareGuideRAG
        self.rag = CareGuideRAG(docs_dir=docs_dir)
        threading.Thread(
            target=lambda: self.after(0, lambda: self._on_init_done(
                self.rag.initialize(
                    lambda m: self.after(0, lambda mm=m: self._add_sys_msg(f"  {mm}", TEXT3))
                )
            )), daemon=True).start()

    def _on_init_done(self, success):
        self.is_initializing = False
        if success:
            self.is_ready = True
            self._set_status("ready", "✅ PDF RAG Ready")
            self._add_sys_msg("── CareGuide AI (PDF Edition) is ready! Ask your first question. ──", JADE)
            self._update_metrics()
        else:
            self.is_ready = False
            self._set_status("error", "❌ Init Failed")
            self._add_sys_msg("── Initialization failed. Check your API key. ──", ROSE)

    # ══ METRICS ═══════════════════════════════════════════════════════════════
    def _update_metrics(self):
        s = self.rag.get_stats() if self.rag else {}
        mt = [m for m in self.conversation if m.get("confidence")]
        conf_vals = [1 if m["confidence"] == "high" else .5 if m["confidence"] == "medium" else .2 for m in mt]
        ca  = sum(conf_vals) / len(conf_vals) if conf_vals else 0
        mem = min(len([m for m in self.conversation if m["role"] == "user"]), 8)
        tok = min(self.total_tokens / 16000, 1.0)
        self._ml["q"].configure(text=str(self.query_count))
        self._ml["v"].configure(text=str(s.get("vectors", "—")))
        self._ml["t"].configure(text=f"{self.total_tokens // 1000}k" if self.total_tokens > 999 else str(self.total_tokens))
        self._ml["d"].configure(text=str(s.get("documents", 12)))
        self._ml["m"].configure(text=f"{mem}/8")
        self._ml["c"].configure(text=f"${self.total_cost:.4f}")
        self._pb["conf"].set(ca);      self._pl["conf"].configure(text=f"{int(ca * 100)}%")
        self._pb["mem"].set(mem / 8);  self._pl["mem"].configure(text=f"{mem}/8")
        self._pb["tok"].set(tok);      self._pl["tok"].configure(text=f"{int(tok * 100)}%")
        self.cost_lbl.configure(text=f"${self.total_cost:.5f}")
        self.stats_label.configure(
            text=f"Queries: {self.query_count}  |  Vectors: {s.get('vectors', '—')}  |  PDFs: {s.get('documents', 12)}")

    def _update_log(self, r):
        self.api_log.configure(state="normal"); self.api_log.delete("1.0", "end")
        t = datetime.datetime.now().strftime("%H:%M:%S")
        u = r.get("usage", {})
        self.api_log.insert("end",
            f"// Response [{t}]\n// confidence: {r.get('confidence')}\n"
            f"// response_time: {r.get('response_time', 0):.2f}s\n"
            f"// is_crisis: {r.get('is_crisis')}\n"
            f"// prompt_tokens: {u.get('prompt_tokens', 0)}\n"
            f"// completion_tokens: {u.get('completion_tokens', 0)}\n"
            f"// sources: {r.get('sources')}\n\n"
            f'// Answer preview:\n"{str(r.get("answer", ""))[:300]}..."')
        self.api_log.configure(state="disabled")

    # ══ STATUS ════════════════════════════════════════════════════════════════
    def _set_status(self, state, text):
        colors = {"ready": JADE, "loading": AMBER, "error": ROSE, "": TEXT3}
        self.status_label.configure(text=f"⬤  {text}", text_color=colors.get(state, TEXT3))
        self.sb_label.configure(text=f"  {text}")

    # ══ UTILITIES ═════════════════════════════════════════════════════════════
    def _show_crisis(self):
        w = ctk.CTkToplevel(self); w.title("Emergency"); w.geometry("420x340")
        w.configure(fg_color="#1A0B0D")
        ctk.CTkLabel(w, text="🚨", font=("Segoe UI Emoji", 40)).pack(pady=(20, 8))
        ctk.CTkLabel(w, text="Emergency Detected",
                     font=("Helvetica", 18, "bold"), text_color=ROSE).pack()
        ctk.CTkLabel(w, text="If this is a medical emergency,\nCALL 911 IMMEDIATELY.\n\n"
                     "Keep person calm and still.\nStay on line with 911 dispatcher.",
                     font=("Helvetica", 12), text_color=TEXT2, justify="center").pack(pady=12)
        ctk.CTkButton(w, text="I understand — continue",
                      fg_color="#4A1A1F", hover_color="#6A2030",
                      text_color=ROSE, command=w.destroy).pack(pady=16, ipadx=16)
        w.grab_set()

    def _clear_chat(self):
        for w in self.chat_frame.winfo_children(): w.destroy()
        if self.rag: self.rag.clear_memory()
        self.conversation = []; self.query_count = 0
        self.total_tokens = 0; self.total_cost = 0.0
        self._add_welcome(); self._update_metrics(); self._reset_pipe()

    def _export_chat(self):
        if not self.conversation:
            messagebox.showinfo("Nothing", "No messages yet."); return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", filetypes=[("Text", "*.txt")],
            initialfile=f"careguide_pdf_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write("CareGuide AI (PDF Edition) Chat Export\n" + "=" * 40 + "\n\n")
                for t in self.conversation:
                    f.write(f"[{t['role'].upper()}]\n{t['content']}\n\n---\n\n")
            messagebox.showinfo("Saved", f"Chat saved to:\n{path}")

    def _slabel(self, p, t):
        ctk.CTkLabel(p, text=t, font=("Courier", 9, "bold"),
                     text_color=TEXT3, anchor="w").pack(fill="x", padx=14, pady=(12, 4))

    def _div(self, p):
        ctk.CTkFrame(p, fg_color=BORDER, height=1, corner_radius=0).pack(fill="x", pady=4)


if __name__ == "__main__":
    app = CareGuideApp()
    app.mainloop()
