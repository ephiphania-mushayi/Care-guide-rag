"""CareGuide AI (PDF Edition) — RAG Engine
Reads PDF knowledge base using pypdf. No LangChain.
"""
import os, re, time, logging
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

CRISIS_RE = re.compile(
    r"\b(fell|fall|fallen|chest pain|cant breathe|can't breathe|not breathing|"
    r"unconscious|unresponsive|heart attack|stroke|seizure|bleeding heavily|"
    r"call 911|emergency help)\b", re.IGNORECASE)

CRISIS_RESPONSE = (
    "EMERGENCY DETECTED\n\n"
    "If this is a medical emergency, CALL 911 IMMEDIATELY.\n\n"
    "While waiting for emergency services:\n"
    "- Keep the person calm and still\n"
    "- Do NOT move someone with a possible spinal injury\n"
    "- If unconscious but breathing, use recovery position\n"
    "- If not breathing, begin CPR if trained\n"
    "- Stay on the line with the 911 dispatcher\n"
    "- Unlock the front door so EMS can enter"
)

SYSTEM = (
    "You are CareGuide AI, an expert caregiving assistant for caregivers.com. "
    "Help families navigate home care using the context provided. "
    "Be warm, empathetic, and specific. Give actionable guidance with real numbers. "
    "Keep responses 150-300 words. End with a concrete next step. "
    "Mention caregivers.com when relevant.\n\nContext:\n{context}"
)


class CareGuideRAG:
    def __init__(self, docs_dir="documents", chroma_dir="chroma_db"):
        self.docs_dir   = docs_dir
        self.chroma_dir = chroma_dir
        self.collection = None
        self.bm25       = None
        self.bm25_docs  = []
        self.client     = None
        self.history    = []
        self._queries   = 0
        self._tokens    = 0
        self.K          = int(os.getenv("MEMORY_K", "8"))

    def initialize(self, status_callback=None):
        try:
            self._log("Initialising CareGuide AI (PDF Edition)...", status_callback)
            import openai, chromadb
            from rank_bm25 import BM25Okapi

            key = os.getenv("OPENAI_API_KEY", "")
            if not key or key == "sk-your-key-here":
                raise ValueError("OPENAI_API_KEY not set.")

            self.client      = openai.OpenAI(api_key=key)
            self.embed_model = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")
            self.chat_model  = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")

            cc    = chromadb.PersistentClient(path=self.chroma_dir)
            names = [c.name for c in cc.list_collections()]

            if "careguide_pdf" in names:
                self._log("Loading existing ChromaDB (PDF)...", status_callback)
                self.collection = cc.get_collection("careguide_pdf")
                self._log(f"Loaded {self.collection.count()} vectors.", status_callback)
                self.bm25_docs = self.collection.get()["documents"]
            else:
                self._log("Extracting text from PDFs...", status_callback)
                chunks = self._chunk_pdfs(status_callback)
                if not chunks:
                    raise ValueError("No PDF files found in documents/ folder.")
                self.collection = cc.create_collection("careguide_pdf")
                self._embed(chunks, status_callback)
                self.bm25_docs = [c["text"] for c in chunks]

            self._log("Building BM25 index...", status_callback)
            self.bm25 = BM25Okapi([d.lower().split() for d in self.bm25_docs])
            self._log(f"CareGuide AI (PDF) ready — {self.collection.count()} vectors.", status_callback)
            return True

        except Exception as e:
            logger.error(f"Init failed: {e}")
            if status_callback: status_callback(f"ERROR: {e}")
            return False

    # ── PDF text extraction ───────────────────────────────────────────────────
    def _extract_pdf_text(self, pdf_path):
        """Extract clean text from a PDF file using pypdf."""
        try:
            from pypdf import PdfReader
            reader = PdfReader(pdf_path)
            pages_text = []
            for page in reader.pages:
                text = page.extract_text() or ""
                # Clean up common PDF extraction artefacts
                text = re.sub(r'\s+', ' ', text)
                text = text.strip()
                if text:
                    pages_text.append(text)
            return "\n\n".join(pages_text)
        except Exception as e:
            logger.warning(f"Could not read {pdf_path}: {e}")
            return ""

    def _chunk_pdfs(self, cb=None):
        """Read all PDFs in docs_dir and split into overlapping chunks."""
        size    = int(os.getenv("CHUNK_SIZE", "800"))
        overlap = int(os.getenv("CHUNK_OVERLAP", "150"))
        chunks  = []
        pdf_files = sorted(Path(self.docs_dir).glob("*.pdf"))

        # Skip the combined all-in-one PDF to avoid duplicate content
        pdf_files = [p for p in pdf_files if "complete" not in p.name.lower()
                     and "combined" not in p.name.lower()]

        for pdf_path in pdf_files:
            self._log(f"  Reading {pdf_path.name}...", cb)
            text = self._extract_pdf_text(str(pdf_path))
            if not text:
                continue
            words = text.split()
            start = 0
            while start < len(words):
                chunk_text = " ".join(words[start:start + size])
                chunks.append({"text": chunk_text, "source": pdf_path.name})
                start += size - overlap

        self._log(f"Created {len(chunks)} chunks from {len(pdf_files)} PDFs.", cb)
        return chunks

    def _embed(self, chunks, cb=None):
        bs = 50
        for i in range(0, len(chunks), bs):
            batch = chunks[i:i + bs]
            resp  = self.client.embeddings.create(
                model=self.embed_model,
                input=[c["text"] for c in batch]
            )
            self.collection.add(
                ids       =[f"c{i+j}" for j in range(len(batch))],
                documents =[c["text"]    for c in batch],
                embeddings=[r.embedding  for r in resp.data],
                metadatas =[{"source": c["source"]} for c in batch],
            )
            self._log(f"  Embedded {min(i+bs, len(chunks))}/{len(chunks)}...", cb)

    # ── Query ─────────────────────────────────────────────────────────────────
    def query(self, question):
        if CRISIS_RE.search(question):
            return {"answer": CRISIS_RESPONSE, "sources": [], "confidence": "crisis",
                    "response_time": 0, "is_crisis": True}
        if not self.collection:
            return {"answer": "System not initialized.", "sources": [], "confidence": "low",
                    "response_time": 0, "is_crisis": False}

        t0 = time.time()
        try:
            k   = int(os.getenv("TOP_K_RESULTS", "5"))
            emb = self.client.embeddings.create(
                model=self.embed_model, input=[question]).data[0].embedding
            sem = self.collection.query(query_embeddings=[emb], n_results=k)
            sdocs, smeta = sem["documents"][0], sem["metadatas"][0]

            scores = self.bm25.get_scores(question.lower().split())
            bidx   = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:k]
            bdocs  = [self.bm25_docs[i] for i in bidx]

            seen, merged = set(), []
            for d in sdocs + bdocs:
                key = d[:80]
                if key not in seen:
                    seen.add(key); merged.append(d)
                if len(merged) >= k:
                    break

            context = "\n\n---\n\n".join(merged[:k])
            sources = list({
                m.get("source", "").replace(".pdf", "").replace("_", " ").title()
                for m in smeta
            })[:3]
            conf = "high" if len(merged) >= 4 else "medium" if len(merged) >= 2 else "low"

            msgs  = [{"role": "system", "content": SYSTEM.format(context=context)}]
            msgs += self.history[-(self.K * 2):]
            msgs.append({"role": "user", "content": question})

            r   = self.client.chat.completions.create(
                model=self.chat_model, messages=msgs,
                temperature=float(os.getenv("TEMPERATURE", "0.3")),
                max_tokens=int(os.getenv("MAX_TOKENS", "1024")),
            )
            ans = r.choices[0].message.content
            self._tokens  += r.usage.total_tokens
            self._queries += 1
            self.history  += [{"role": "user", "content": question},
                               {"role": "assistant", "content": ans}]
            if len(self.history) > self.K * 2:
                self.history = self.history[-(self.K * 2):]

            return {"answer": ans, "sources": sources, "confidence": conf,
                    "response_time": time.time() - t0, "is_crisis": False,
                    "usage": {"prompt_tokens": r.usage.prompt_tokens,
                              "completion_tokens": r.usage.completion_tokens}}

        except Exception as e:
            msg = str(e)
            if "auth" in msg.lower():   msg = "Invalid API key. Check your key in the sidebar."
            elif "rate" in msg.lower(): msg = "Rate limit reached. Wait a moment."
            return {"answer": f"Error: {msg}", "sources": [], "confidence": "low",
                    "response_time": time.time() - t0, "is_crisis": False}

    def clear_memory(self):
        self.history = []

    def rebuild_index(self, cb=None):
        import shutil
        if os.path.exists(self.chroma_dir):
            shutil.rmtree(self.chroma_dir)
        self.collection = self.bm25 = None
        self.bm25_docs  = []
        return self.initialize(cb)

    def get_stats(self):
        pdf_count = len([p for p in Path(self.docs_dir).glob("*.pdf")
                         if "complete" not in p.name.lower()])
        return {
            "queries":     self._queries,
            "vectors":     self.collection.count() if self.collection else 0,
            "documents":   pdf_count,
            "model":       os.getenv("OPENAI_MODEL", "gpt-3.5-turbo"),
            "search_mode": "Hybrid BM25 + Semantic (PDF)",
            "memory_k":    self.K,
        }

    @staticmethod
    def _log(msg, cb=None):
        logger.info(msg)
        if cb: cb(msg)
